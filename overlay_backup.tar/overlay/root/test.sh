a=`ps | grep /usr/bin/ss-redir | grep -v grep`

if [[ "$a" ]]
then
	echo 'haha'
fi
