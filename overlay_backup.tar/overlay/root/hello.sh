#ss=`ps | grep /usr/bin/ss-redir | grep -v grep`

if ! (ps | grep /usr/bin/ss-redir | grep -v grep); then
	echo  `date` 'Stopped!!!' >> /root/log
	/etc/init.d/shadowsocks restart
fi
